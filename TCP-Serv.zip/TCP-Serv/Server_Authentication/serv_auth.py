import socket
import time

#Считываю списки пользователей
with open("../users.txt", "r") as file:
    users = [line.split() for line in file.readlines()]

#Сокет по умолчанию
sock = socket.socket()
sock.bind(('127.0.0.1', 9090))
sock.listen(1)
client_socket, addr = sock.accept()
Identification = False



#Идентификация
#Ищу пользователся в зарегистрированных
for user in users:
    #Если пользователь зарегистрирован, приветсвую и меняю флаг Identification
    if user[0] == str(addr[0]):
        try:
            client_socket.send((f"Здравствуйте, {user[1]}\n").encode())
            Identification = True
            break
        except:
            pass
#Если пользователь не зарегистрирован, провожу регистрацию
if not Identification:
    client_socket.send(("Здравствуйте!\n").encode())
    while True:
        client_socket.send(("Введите\n").encode())
        msg = client_socket.recv(1024).decode()
        if msg != "":
            users.append([addr[0], msg])
            with open("../users.txt", "w") as file:
                for line in users:
                    file.write(" ".join(line))
            client_socket.send((f"Очень приятно, {msg}\n").encode())
            break
        else:
            client_socket.send(("Пустое поле\nВведите заново").encode())




#Пароль
for user in users:
    if user[0] == str(addr[0]):
        while True:
            try:
                if user[2] != "":
                    client_socket.send(("Введите пароль для входа: ").encode())
                    msg = client_socket.recv(1024).decode()
                    if msg == user[2]:
                        client_socket.send(("Вход выполнен\n Введите новое сообщение: ").encode())
                        break
                    else:
                        client_socket.send(("Неверный пароль\n").encode())
            except IndexError:
                client_socket.send(("Придумайте пароль: ").encode())
                msg = client_socket.recv(1024).decode()
                while True:
                    if msg != "":
                        user.append(msg)
                        with open("../users.txt", "w") as file:
                            for line in users:
                                file.write(" ".join(line))
                        break
                    else:
                        client_socket.send(("Введите пароль: ").encode())






while True:
    msg = client_socket.recv(1024).decode()
    print(msg)
    client_socket.send(msg.encode())
    client_socket.send(("\nВведите новое сообщение: ").encode())
    if msg == "exit" or msg == "":
        break