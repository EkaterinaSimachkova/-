def CorrectIp(ip):
    ip = ip.split(".")
    for part_ip in ip:
        if not (0 <= part_ip <= 255):
            return False
    return True

