import socket

#Проверка IP на валидность
def CorrectIp(ip):
    ip = ip.split(".")
    if len(ip) != 4:
        return False
    for part_ip in ip:
        if not (0 <= int(part_ip) <= 255):
            return False
    return True



#Сокет по умолчанию
sock = socket.socket()
sock.setblocking(1)
sock.connect(('127.0.0.1', 9090))

#Сокет по запросу
work_sock = socket.socket()
work_sock.setblocking(1)


while True:
    #Получение данных
    host = input("Введите номер хоста в формате 0.0.0.0: ")
    port = input("Введите номер порта (1024 - 65535): ")

    #Проверка на пустоту
    if not host or not port:
        print("Один из параметров пуст")
        decision = input("Хотите подключится по умолчанию? (Y/N)\n"
                         "Ответ: ")
        #При согласии клиента сокет по умолчанию становится
        if decision == "Y":
            #Отправляю на сервер сообщение о подключении клиента к дефолтному порту
            sock.send(("DEFAULT").encode())
            #Планируемый сокет для работы (work_sock) закрывается
            work_sock.close()
            #Сокет по умолчанию становится рабочим
            work_sock = sock
            print("Вы подключены по следующим параметрам:\nIP: '127.0.0.1'\nPort: 9090")
            break

        elif decision == "N":
            print("\nВведите параметры заново")

    #При непустых параметрах, проверяем их корректность
    elif CorrectIp(host) and (1024 < int(port) < 65535):
        #Отправка желаемых параметров
        msg = host + ";" + port
        sock.send(msg.encode())

        # Получение сообщения о готовности подключения
        msg = sock.recv(1024).decode()

        #Сервер смог подключиться по желаемым параметрам
        if msg == "SUCCESS":
            work_sock.connect((host, int(port)))
            sock.close()
            print(f"Вы подключены по следующим параметрам:\nIP: '{host}'\nPort: {port}")
            break


        #Если желаемый порт был заня, подключаем клиента к случайному порту
        elif msg == "RANDOM":
            while True:
                #Принимаю от сервера номер порта
                port = sock.recv(1024).decode()
                try:
                    work_sock.connect((host, int(port)))
                    sock.close()
                    print(f"Порт был занят\nВы подключены по следующим параметрам:\nIP: '{host}'\nPort: {port}")
                    break
                except:
                    pass
            break
    else:
        print("Введены некорректные данные\n"
              "Введите параметры заново")





while True:
    msg = input()
    work_sock.send(msg.encode())
    print(work_sock.recv(1024).decode())

    if msg == "exit":
        break

work_sock.close()


