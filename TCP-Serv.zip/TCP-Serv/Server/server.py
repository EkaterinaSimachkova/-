import socket
import logging
import time

#Файл служебных записей
logging.basicConfig(format='%(asctime)s - %(message)s',
					datefmt='%d-%b-%y %H:%M:%S',
					filename="log.txt",
					level=logging.DEBUG)


def ServStart():
	#Сокет по умолчанию
	sock = socket.socket()
	#Настройка позволяющая использовать сокет заново
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	sock.bind(('127.0.0.1', 9090))
	sock.listen(1)
	client_socket, addr = sock.accept()


	#Сокет по запросу
	work_sock = socket.socket()
	#Настройка позволяющая использовать сокет заново
	work_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)


	#Процесс подключения
	while True:
		#Получение запроса от клиента
		msg = client_socket.recv(1024).decode()

		#Подключение по умолчанию
		if msg == "DEFAULT":
			logging.info("Клиент подключен по умолчанию\n"
						 "Port: 9090")
			work_client_socket, work_addr = client_socket, addr
			sock.close()
			break


		#Сокет по запросу
		try:
			work_client_socket, work_addr = msg.split(";")
			work_sock.bind((str(work_client_socket), int(work_addr)))
			work_sock.listen(1)
			client_socket.send("SUCCESS".encode())
			work_client_socket, work_addr = work_sock.accept()
			logging.info(f"Клиент подключен к порту {work_addr}")
			sock.close()
			break

		#При занятом порте, ищем свободный и подключаем по нему
		except OSError:
			work_addr = 1024
			while True:
				if work_addr < 65535:
					work_addr += 1
				else:
					work_addr = 1024
				try:
					work_sock.bind((str(work_client_socket), work_addr))
					work_sock.listen(1)
					client_socket.send("RANDOM".encode())
					#Даем время для подключения
					time.sleep(1)
					client_socket.send(str(work_addr).encode())
					work_client_socket, work_addr = work_sock.accept()
					sock.close()
					break
				except ValueError:
					pass
			break



	logging.info(f"Начало прослушивания {work_addr}")
	while True:
		msg = work_client_socket.recv(1024).decode()
		logging.info("Прием данных от клиента")
		print(msg)
		work_client_socket.send(msg.encode())
		logging.info("Отправка данных клиенту")

		if msg == "exit":
			logging.info("Клиент отключен")
			break

		elif msg == "":
			logging.info("Разрыв соединения")
			work_sock.close()
			time.sleep(1)
			ServStart()

	work_sock.close()
	logging.info("Сервер закрыт")


#Запуск основго процесса
ServStart()