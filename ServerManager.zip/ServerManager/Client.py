import socket

HOST = 'localhost'
PORT = 9090


sock = socket.socket()
sock.connect((HOST, PORT))

response = sock.recv(1024).decode()
print(response)

while True:
    request = input('> ')

    if request[0] == 'cpToServ':
        content = []
        with open(f"{request[1]}", "r") as file:
            for line in file:
                content.append(line)
        request += ' ' + ''.join(content)

    sock.send(request.encode())

    response = sock.recv(1024).decode()

    if response == "CLOSE":
        sock.close()
        break

    elif response.split(" ")[0] == "FILE":
        request = request.split()
        with open(f"{request[2]}", "w") as file:
            file.write(' '.join(response.split(" ")[1:]))
        print(response)
        print("файл скопирован")
        continue

    print(response)


sock.close()
