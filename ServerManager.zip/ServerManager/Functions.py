import os
import shutil

global HomePath



# Установка рабочей папки
def WorkPath(user_name):
    global HomePath
    if user_name != "Admin":
        HomePath = f"{HomePath}\\{user_name}"

        try:
            os.chdir(HomePath)
        except FileNotFoundError:
            os.mkdir(HomePath)
            os.chdir(HomePath)

    else:
        pass



# Проверка пути на валидность
def CheckPath(path):
    global HomePath
    if len(path.split("\\")) == 1:
        if HomePath in os.getcwd():
            return True
    else:
        if HomePath in path[:len(HomePath)]:
            return True
    return False


# создать пустой каталог (папку)
def CreateNewFolder(folder):
    global HomePath
    try:
        if not os.path.isdir(str(folder)) and CheckPath(folder):
            os.mkdir(str(folder))
            if os.path.getsize(HomePath) + os.path.getsize(folder) > 2000:
                return "Нет места"
            else:
                return "каталог создан"
        else:
            return "Нет разрешения"
    except FileExistsError:
        return "Файл с таким именем уже существует"


# удалить папку
def DeleteFolder(folder):
    if CheckPath(folder):
        os.rmdir(str(folder))
        return "каталог удален"
    else:
        return "Нет разрешения"


# вернуться в предыдущую директорию
def FolderLevelUp():
    if os.getcwd() != HomePath:
        os.chdir("..")
        return "текущий каталог изменен"
    else:
        return "Нет разрешения"


# перейти в другой каталог
def MoveToFolder(path):
    if CheckPath(path):
        os.chdir(path)
        return "текущий каталог изменен"
    else:
        return "Нет разрешения"


# создать новый текстовый файл
def CreateNewFile(file):
    try:
        if CheckPath(file):
            text_file = open(f"{file}", "w")
            text_file.close()
        else:
            return "Нет разрешения"
    except FileExistsError:
        return "Файл с таким именем уже существует"


# записать текст в этот файл
def WriteInFile(file, text):
    if CheckPath(file):
        with open(f"{file}", "a") as file:
            file.write(text)
    else:
        return "Нет разрешения"


# вывести содержимое файла
def ShowFile(file):
    if CheckPath(file):
        content = []
        with open(f"{file}", "r") as file:
            for line in file:
                content.append(line)
        return ''.join(content)
    else:
        return "Нет разрешения"


# удалить этот файл
def DeleteFile(file):
    if CheckPath(file):
        os.remove(f"{file}")
        return "файл удален"
    else:
        return "Нет разрешения"


# копировать файл
def CopyFile(file, path):
    if CheckPath(file) and CheckPath(path):
        shutil.copy(fr"{file}", f"{path}")
        if os.path.getsize(HomePath) + os.path.getsize(path) > 2000:
            return "Нет места"
        else:
            return "файл скопирован"
    else:
        return "Нет разрешения"


# заменить (переместить) этот файл в другой каталог
def MoveFile(file, path):
    if CheckPath(file) and CheckPath(path):
        os.replace(fr"{file}", f"{path}\\" + str(file.split('\\')[-1]))
        if os.path.getsize(HomePath) + os.path.getsize(f"{path}\\" + str(file.split('\\')[-1])) > 2000:
            return "Нет места"
        else:
            return "файл перемещен"
    else:
        return "Нет разрешения"


# переименовать
def RenameFile(file, new_file):
    if CheckPath(file):
        if len(file.split("\\")) == 1:
            if len(new_file.split("\\")) == 1:
                os.rename(f"{file}", f"{new_file}")
                return "файл переименован"
        else:
            if len(new_file.split("/")) == 1:
                os.rename(f"{file}", str(file[:-len(file.split('\\')[-1])]) + f"\\{new_file}")
                return "файл переименован"
    else:
        return "Нет разрешения"


def Registration(conn):
    global HomePath
    Registration = False
    FilesPath = os.getcwd()
    with open(f"{FilesPath}\Settings", "r") as file:
        HomePath = file.read()
    os.chdir(HomePath)

    # Получение списка зарегистрированных пользователей
    with open(f"{FilesPath}\\users", "r") as file:
        users = [name.split() for name in file.readlines()]

    conn.send(("Введите имя: ").encode())
    user_name = conn.recv(1024).decode()





    for user in users:
        if user_name == user[0]:
            conn.send(("Введите пароль: ").encode())
            password = conn.recv(1024).decode()
            while password != user[1]:
                conn.send(("Неверный пароль\nВведите пароль заново: ").encode())
                password = conn.recv(1024).decode()
            Registration = True
            conn.send(("Вы успешно авторизованны").encode())
            break
    if not Registration:
        conn.send(("Придумайте пароль: ").encode())
        password = conn.recv(1024).decode()
        users.append([user_name, password])
        with open(f"{FilesPath}\\users", "w") as file:
            for user in users:
                file.write(" ".join(user) + "\n")
        conn.send(("Вы успешно авторизованны").encode())

    WorkPath(user_name)
