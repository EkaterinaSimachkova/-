import socket
from Functions import *
import logging


logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename="log.txt", level=logging.DEBUG)

def process(req, HomePath):
    req = req.split()
    try:
        if req[0] == "help":
            return '''ls [DIRECTORY]- выводит содержимое каталога
pwd - выводит путь текущего каталога
mkdir DIRECTORY - создает каталог
rmdir DIRECTORY - удаляет каталог
cd DIRECTORY - меняет текущий каталог
touch FILE [TEXT] - создает пустой файл или файл с текстом
rm FILE - удаляет файл
mv SOURCE DESTINATION - перемещает файл
rename FILE NEWNAME - переименовывает файл
cp SOURCE DESTINATION - копирует файл
cat FILE - выводит содержимое файла
cpFromServ SOURCE DESTINATION - копирует файл с сервера на клиент
cpToServ SOURCE DESTINATION - копирует файл с клиента на сервер
help - выводит справку по командам
exit - разрыв соединения с сервером'''

        elif req[0] == 'pwd':
            return os.getcwd()

        elif req[0] == 'ls':
            return '; '.join(os.listdir(' '.join(req[1:])))

        elif req[0] == "mkdir":
            return CreateNewFolder(req[1])

        elif req[0] == "rmdir":
            return DeleteFolder(req[1])

        elif req[0] == "cd":
            if req[1] == '..':
                return FolderLevelUp()
            else:
                return MoveToFolder(req[1])

        elif req[0] == "touch":
            CreateNewFile(req[1])
            WriteInFile(req[1], ' '.join(req[2:]))
            if os.path.getsize(HomePath) + os.path.getsize(req[1]) > 2000:
                return "Нет места"
            else:
                return "файл создан"

        elif req[0] == "rm":
            return DeleteFile(req[1])

        elif req[0] == "mv":
            return MoveFile(req[1], req[2])

        elif req[0] == "rename":
            return RenameFile(req[1], req[2])

        elif req[0] == "cp":
            return CopyFile(req[1], req[2])

        elif req[0] == "cat":
            return ShowFile(req[1])

        elif req[0] == "cpFromServ":
            return f'FILE {ShowFile(req[1])}'

        elif req[0] == "cpToServ":
            CreateNewFile(req[2])
            WriteInFile(req[2], ' '.join(req[3:]))
            if os.path.getsize(HomePath) + os.path.getsize(req[2]) > 2000:
                return "Нет места"
            else:
                return "файл скопирован"

        elif req[0] == "exit":
            return "CLOSE"

        else:
            return'bad request\nВывод справки по командам - help'

    except IndexError:
        return "bad request\nВывод справки по командам - help"


PORT = 9090
sock = socket.socket()
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(('', PORT))
sock.listen()

print("Слушаем порт", PORT)
logging.info(f"Слушаем порт {PORT}")
conn, addr = sock.accept()
print(addr)
logging.info(f"Подключен клиент {addr}")

Registration(conn)
logging.info(f"Клиент {addr} прошел авторизацию")
while True:

    from Functions import HomePath
    request = conn.recv(1024).decode()
    response = process(request, HomePath)
    conn.send(response.encode())

    if response == "CLOSE":
        sock.close()
        logging.info(f"Соединение с клиентом {addr} разорвано")
        break
