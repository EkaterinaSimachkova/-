import socket
import threading

sock = socket.socket()
sock.bind(('127.0.0.1', 9090))
sock.listen(1)


def ThreadFunc():
	client_socket, addr = sock.accept()
	global NewThread
	NewThread = True

	while True:
		msg = client_socket.recv(1024).decode()
		print(msg)
		client_socket.send(msg.encode())
		if msg == "exit":
			sock.close()
			break

NewThread = True


while True:
	if NewThread:
		threading.Thread(target=ThreadFunc).start()
		NewThread = False



