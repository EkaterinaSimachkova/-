import socket
import threading

# Сокет по умолчанию
import time

sock = socket.socket()
sock.setblocking(1)
sock.connect(('127.0.0.1', 9090))
msg = ""
Flag = True


def RecV():
    while True:
        serv_msg = sock.recv(1024).decode()
        print(serv_msg)


def SenD():
    while True:
        msg = input()
        sock.send(msg.encode())

        if msg == "exit":
            global Flag
            Flag = False
            sock.close()
            break


t1 = threading.Thread(target=RecV).start()
t2 = threading.Thread(target=SenD).start()


