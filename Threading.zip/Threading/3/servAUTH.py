import socket
import threading
import logging

#Файл служебных записей
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename="log.txt", level=logging.DEBUG)

try:
    file = open("users.txt", "r")
    users = [line[:-1].split(";") for line in file.readlines()]
    file.close()
except FileNotFoundError:
    file = open("users.txt", "w")
    file.close()


#Сокет по умолчанию
sock = socket.socket()
sock.bind(('127.0.0.1', 9090))
sock.listen(1)

#Список подключенных пользователей
Users = []

def ThreadFunc():
    global Users
    client_socket, addr = sock.accept()
    Users.append(client_socket)
    print(addr)
    global NewThread
    NewThread = True
    Ident = False

    #Идентификация
    try:
        for user in users:
            if user[0] == str(addr):
                name = user[1]
                client_socket.send((f"Здравствуйте, {name}\n").encode())
                Ident = True
                break
    except:
        pass

    if not(Ident):
        client_socket.send(("Здравствуйте!\n").encode())
        while True:
            client_socket.send(("Как я могу к Вам обращаться?)\n").encode())
            msg = client_socket.recv(1024).decode()
            if msg != "":
                name = msg
                users.append([str(addr), name])
                with open("users.txt", "w") as file:
                    for line in users:
                        file.write(";".join(line))
                        file.write("\n")
                client_socket.send((f"Отлично!) Очень приятно, {name}\n").encode())
                break
            else:
                client_socket.send(("Что-то пошло не так(\n").encode())

    # Пароль
    for user in users:
        print(user)
        if user[0] == str(addr):
            while True:
                try:
                    if user[2] != "":
                        client_socket.send(("Введите пароль для входа: ").encode())
                        msg = client_socket.recv(1024).decode()
                        if msg == user[2]:
                            client_socket.send(("Вход выполнен\n Введите новое сообщение: ").encode())
                            break
                        else:
                            client_socket.send(("Неверный пароль\n").encode())
                except:
                    client_socket.send(
                        ("Похоже, что у Вас еще нет пароля. Давайте установим его.\n Введите пароль: ").encode())
                    msg = client_socket.recv(1024).decode()
                    while True:
                        if msg != "":
                            user.append(msg)
                            with open("users.txt", "w") as file:
                                for line in users:
                                    file.write(";".join(line))
                                    file.write("\n")
                            break
                        else:
                            client_socket.send(("Введите пароль: ").encode())
                    break

    while True:
        msg = client_socket.recv(1024).decode()
        print(f"{name}: {msg}")
        print(Users)
        for client_socket_from_list in Users:
            if client_socket_from_list != client_socket:
                try:
                    client_socket_from_list.send((f"{name}: {msg}").encode())
                except:
                    pass
        logging.info(f"{name}: {msg}")
        client_socket.send(msg.encode())
        if msg == "exit":
            break




NewThread = True


while True:
    if NewThread:
        threading.Thread(target=ThreadFunc).start()
        NewThread = False