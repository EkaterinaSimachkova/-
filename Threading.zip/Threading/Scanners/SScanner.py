import socket
import threading
from progress.bar import IncrementalBar


ip = input("Введите имя хоста: ")
ListOfPorts = []
start = 1
stop = 1000
bar = IncrementalBar('Scanning', max = stop - start + 1)

def scan_port(port):
    sock = socket.socket()
    sock.settimeout(0.5)
    try:
        sock.connect_ex((ip, port))
        ListOfPorts.append(port)
        sock.close()
    except:
        pass



for n in range(start, stop + 1, 3):
    if n <= stop:
        p1 = threading.Thread(target=scan_port, name="t1", args=[n])
        bar.next()
        p1.start()
    if n + 1 <= stop:
        p2 = threading.Thread(target=scan_port, name="t2", args=[n + 1])
        bar.next()
        p2.start()
    if n + 2 <= stop:
        p3 = threading.Thread(target=scan_port, name="t3", args=[n + 2])
        bar.next()
        p3.start()

ListOfPorts.sort()
bar.finish()

for port in ListOfPorts:
    print(f"Порт {port} открыт")