import socket
import threading
from progress.bar import IncrementalBar
from datetime import datetime

start = datetime.now()


PORTS = []


def scan_port(port):
    sock = socket.socket()
    sock.settimeout(0.5)
    try:
        sock.connect((ip, port))
        PORTS.append(port)
        sock.close()
    except:
        pass


ip = input("Введите имя хоста: ")
#ip = "www.fa.ru"
bar = IncrementalBar('Scanning', max=10000)

for n in range(1000):
    threading.Thread(target=scan_port, name="n", args=[n]).start()
    bar.next()

bar.finish()
PORTS.sort()

for port in PORTS:
    print(f"Порт {port} открыт")


end = datetime.now()
print(f"Time: {end-start}")