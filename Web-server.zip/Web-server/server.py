import socket, datetime, os, threading, logging

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename="log.txt", level=logging.DEBUG)

with open("settings.txt", "r") as file:
    port = file.readline().split()[1]
    directory = file.readline().split()[1]
    size = file.readline().split()[1]
    requests = int(file.readline().split()[1])

sock = socket.socket()
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

try:
    sock.bind(('', int(port)))
    print(f"Using port {port}")
except OSError:
    sock.bind(('', 80))
    print("Using port 80")

os.chdir(directory)

sock.listen(int(requests))

def NewRequest():
    conn, addr = sock.accept()
    print("Connected", addr)

    data = conn.recv(int(size))
    msg = data.decode()
    print(msg)

    Request = msg.split()[1]

    if Request != '/':
        if ".html" in Request or ".js" in Request or ".css" in Request:
            try:
                file = open(Request[1:], "r")
                ReqFile = file.read()
                file.close()
            except FileNotFoundError:
                file = open("404Error.html", "r")
                ReqFile = file.read()
                file.close()
                logging.error(f"Адрес клиента: {addr}; запрашиваемый файл: {Request[1:]}; код ошибки: 404")
        else:
            file = open("403Error.html", "r")
            ReqFile = file.read()
            file.close()
            logging.error(f"Адрес клиента: {addr}; запрашиваемый файл: {Request[1:]}; код ошибки: 403")
    else:
        with open("index.html") as file:
            ReqFile = file.read()
            file.close()

    now = datetime.datetime.now()

    resp = f"""HTTP/1.1 200 OK
Date: {now.strftime("%a, %d %b %Y %H:%M:%S")}
Server: SelfMadeServer v0.0.1
Content-Length: {len(ReqFile)}
Content-Type: text/html
Connection: close

{ReqFile}"""

    print(resp)
    conn.send(resp.encode())
    conn.close()

    global requests
    requests += 1

while True:
    if requests > 0:
        threading.Thread(target=NewRequest()).start()
        requests -= 1

